-- Banco de Dados: canticosccb_plataforma
-- Tabela de Hinos

CREATE TABLE IF NOT EXISTS `hinos` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero` INT(11) DEFAULT NULL COMMENT 'Número do hino (ex: 1, 2, 249)',
  `titulo` VARCHAR(255) NOT NULL COMMENT 'Título do hino',
  `compositor` VARCHAR(255) DEFAULT NULL COMMENT 'Nome do compositor',
  `categoria` VARCHAR(100) DEFAULT NULL COMMENT 'Categoria/Tema do hino',
  `audio_url` VARCHAR(500) NOT NULL COMMENT 'URL do arquivo de áudio',
  `cover_url` VARCHAR(500) DEFAULT NULL COMMENT 'URL da capa/imagem',
  `duracao` INT(11) DEFAULT NULL COMMENT 'Duração em segundos',
  `letra` TEXT DEFAULT NULL COMMENT 'Letra completa do hino',
  `tags` TEXT DEFAULT NULL COMMENT 'Tags separadas por vírgula',
  `ativo` TINYINT(1) DEFAULT 1 COMMENT '1 = ativo, 0 = inativo',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_numero` (`numero`),
  INDEX `idx_categoria` (`categoria`),
  INDEX `idx_ativo` (`ativo`),
  INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tabela de Hinos';

-- Inserir alguns hinos de exemplo (opcional)
INSERT INTO `hinos` (`numero`, `titulo`, `compositor`, `categoria`, `audio_url`, `cover_url`, `letra`, `tags`) VALUES
(1, 'Grande Deus', 'Desconhecido', 'Louvor', 'https://canticosccb.com.br/media/hinos/001-grande-deus.mp3', NULL, 'Grande Deus, eterno Pai...', 'louvor,adoração'),
(249, 'O Vem, Jesus', 'Desconhecido', 'Advento', 'https://canticosccb.com.br/media/hinos/249-o-vem-jesus.mp3', NULL, 'Ó vem, Jesus, redentor...', 'advento,retorno')
ON DUPLICATE KEY UPDATE titulo = VALUES(titulo);

-- Criar tabela de categorias
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `descricao` TEXT DEFAULT NULL,
  `ordem` INT(11) DEFAULT 0,
  `ativo` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir categorias padrão
INSERT INTO `categorias` (`nome`, `slug`, `descricao`, `ordem`) VALUES
('Louvor', 'louvor', 'Hinos de louvor e adoração', 1),
('Gratidão', 'gratidao', 'Hinos de gratidão', 2),
('Oração', 'oracao', 'Hinos de oração', 3),
('Advento', 'advento', 'Hinos sobre o retorno de Cristo', 4),
('Santa Ceia', 'santa-ceia', 'Hinos para Santa Ceia', 5),
('Batismo', 'batismo', 'Hinos para batismo', 6),
('Casamento', 'casamento', 'Hinos para casamento', 7),
('Funeral', 'funeral', 'Hinos para funeral', 8)
ON DUPLICATE KEY UPDATE nome = VALUES(nome);

-- Criar tabela de compositores
CREATE TABLE IF NOT EXISTS `compositores` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `foto_url` VARCHAR(500) DEFAULT NULL,
  `biografia` TEXT DEFAULT NULL,
  `total_hinos` INT(11) DEFAULT 0,
  `ativo` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Criar tabela de estatísticas (plays, likes, etc)
CREATE TABLE IF NOT EXISTS `hino_stats` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `hino_id` INT(11) UNSIGNED NOT NULL,
  `plays` INT(11) DEFAULT 0,
  `likes` INT(11) DEFAULT 0,
  `shares` INT(11) DEFAULT 0,
  `downloads` INT(11) DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_hino_id` (`hino_id`),
  FOREIGN KEY (`hino_id`) REFERENCES `hinos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Criar índices adicionais para performance
ALTER TABLE `hinos` ADD FULLTEXT INDEX `idx_fulltext_search` (`titulo`, `letra`, `tags`);

-- Criar trigger para atualizar total_hinos do compositor
DELIMITER //
CREATE TRIGGER `update_compositor_total_hinos` 
AFTER INSERT ON `hinos`
FOR EACH ROW
BEGIN
  UPDATE `compositores` 
  SET `total_hinos` = (SELECT COUNT(*) FROM `hinos` WHERE `compositor` = NEW.compositor)
  WHERE `nome` = NEW.compositor;
END//
DELIMITER ;

-- Ver tabelas criadas
SHOW TABLES;

-- Ver estrutura da tabela hinos
DESCRIBE hinos;
