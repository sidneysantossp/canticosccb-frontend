<?php
/**
 * Configuração da API - Backend PHP
 */

// CORS Headers (permitir requisições do frontend)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Configuração do Banco de Dados
define('DB_HOST', '203.161.46.119');
define('DB_USER', 'canticosccb_plataforma');
define('DB_PASS', 'Sidney10@KmSs147258!@#$%');
define('DB_NAME', 'canticosccb_plataforma');

// Diretórios de Upload
define('UPLOAD_DIR_AUDIO', $_SERVER['DOCUMENT_ROOT'] . '/media/hinos/');
define('UPLOAD_DIR_COVER', $_SERVER['DOCUMENT_ROOT'] . '/media/albuns/');
define('UPLOAD_DIR_AVATAR', $_SERVER['DOCUMENT_ROOT'] . '/media/avatars/');

// URLs públicas
define('MEDIA_BASE_URL', 'https://canticosccb.com.br/media');

// Tamanhos máximos de upload
define('MAX_AUDIO_SIZE', 50 * 1024 * 1024); // 50 MB
define('MAX_IMAGE_SIZE', 10 * 1024 * 1024); // 10 MB

// Formatos permitidos
define('ALLOWED_AUDIO_FORMATS', ['mp3', 'wav', 'ogg', 'm4a']);
define('ALLOWED_IMAGE_FORMATS', ['jpg', 'jpeg', 'png', 'webp']);

/**
 * Função para conectar ao banco de dados
 */
function getDBConnection() {
    try {
        $conn = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
        return $conn;
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Erro de conexão: ' . $e->getMessage()]);
        exit;
    }
}

/**
 * Função para sanitizar nome de arquivo
 */
function sanitizeFilename($filename) {
    // Remove extensão
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $name = pathinfo($filename, PATHINFO_FILENAME);
    
    // Sanitiza nome
    $name = mb_strtolower($name);
    $name = iconv('UTF-8', 'ASCII//TRANSLIT', $name);
    $name = preg_replace('/[^a-z0-9-]/', '-', $name);
    $name = preg_replace('/-+/', '-', $name);
    $name = trim($name, '-');
    
    // Adiciona timestamp para evitar duplicatas
    $name = $name . '-' . time();
    
    return $name . '.' . $ext;
}

/**
 * Função para responder JSON
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Função para logar erros
 */
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, __DIR__ . '/error.log');
}
?>
