<?php
/**
 * API: Upload de Arquivo de Áudio
 * POST /api/upload/audio
 */

require_once __DIR__ . '/../config.php';

// Verificar se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Método não permitido'], 405);
}

// Verificar se arquivo foi enviado
if (!isset($_FILES['audio']) || $_FILES['audio']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(['error' => 'Nenhum arquivo de áudio enviado'], 400);
}

$file = $_FILES['audio'];

// Validar tamanho
if ($file['size'] > MAX_AUDIO_SIZE) {
    jsonResponse([
        'error' => 'Arquivo muito grande. Máximo: ' . (MAX_AUDIO_SIZE / 1024 / 1024) . ' MB'
    ], 400);
}

// Validar formato
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ALLOWED_AUDIO_FORMATS)) {
    jsonResponse([
        'error' => 'Formato não permitido. Use: ' . implode(', ', ALLOWED_AUDIO_FORMATS)
    ], 400);
}

// Criar diretório se não existir
if (!file_exists(UPLOAD_DIR_AUDIO)) {
    mkdir(UPLOAD_DIR_AUDIO, 0755, true);
}

// Sanitizar nome do arquivo
$filename = sanitizeFilename($file['name']);
$filepath = UPLOAD_DIR_AUDIO . $filename;

// Mover arquivo
if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    logError('Erro ao mover arquivo de áudio: ' . $file['name']);
    jsonResponse(['error' => 'Erro ao salvar arquivo'], 500);
}

// Definir permissões
chmod($filepath, 0644);

// Retornar sucesso
jsonResponse([
    'success' => true,
    'filename' => $filename,
    'url' => MEDIA_BASE_URL . '/hinos/' . $filename,
    'size' => $file['size']
], 201);
?>
