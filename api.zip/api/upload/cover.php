<?php
/**
 * API: Upload de Capa/Imagem
 * POST /api/upload/cover
 */

require_once __DIR__ . '/../config.php';

// Verificar se é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Método não permitido'], 405);
}

// Verificar se arquivo foi enviado
if (!isset($_FILES['cover']) || $_FILES['cover']['error'] !== UPLOAD_ERR_OK) {
    jsonResponse(['error' => 'Nenhuma imagem enviada'], 400);
}

$file = $_FILES['cover'];

// Validar tamanho
if ($file['size'] > MAX_IMAGE_SIZE) {
    jsonResponse([
        'error' => 'Imagem muito grande. Máximo: ' . (MAX_IMAGE_SIZE / 1024 / 1024) . ' MB'
    ], 400);
}

// Validar formato
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ALLOWED_IMAGE_FORMATS)) {
    jsonResponse([
        'error' => 'Formato não permitido. Use: ' . implode(', ', ALLOWED_IMAGE_FORMATS)
    ], 400);
}

// Validar se é realmente uma imagem
$imageInfo = getimagesize($file['tmp_name']);
if ($imageInfo === false) {
    jsonResponse(['error' => 'Arquivo não é uma imagem válida'], 400);
}

// Criar diretório se não existir
if (!file_exists(UPLOAD_DIR_COVER)) {
    mkdir(UPLOAD_DIR_COVER, 0755, true);
}

// Sanitizar nome do arquivo
$filename = sanitizeFilename($file['name']);
$filepath = UPLOAD_DIR_COVER . $filename;

// Mover arquivo
if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    logError('Erro ao mover arquivo de imagem: ' . $file['name']);
    jsonResponse(['error' => 'Erro ao salvar imagem'], 500);
}

// Definir permissões
chmod($filepath, 0644);

// Retornar sucesso
jsonResponse([
    'success' => true,
    'filename' => $filename,
    'url' => MEDIA_BASE_URL . '/albuns/' . $filename,
    'size' => $file['size'],
    'dimensions' => [
        'width' => $imageInfo[0],
        'height' => $imageInfo[1]
    ]
], 201);
?>
