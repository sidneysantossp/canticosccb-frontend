<?php
/**
 * API: CRUD de Hinos
 * GET    /api/hinos - Listar hinos
 * POST   /api/hinos - Criar hino
 * GET    /api/hinos/:id - Buscar hino
 * PUT    /api/hinos/:id - Atualizar hino
 * DELETE /api/hinos/:id - Deletar hino
 */

require_once __DIR__ . '/../config.php';

$conn = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

// Extrair ID da URL se existir
preg_match('/\/api\/hinos\/(\d+)/', $uri, $matches);
$id = $matches[1] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            // Buscar hino específico
            getHino($conn, $id);
        } else {
            // Listar hinos
            listHinos($conn);
        }
        break;
        
    case 'POST':
        // Criar hino
        createHino($conn);
        break;
        
    case 'PUT':
        if ($id) {
            // Atualizar hino
            updateHino($conn, $id);
        } else {
            jsonResponse(['error' => 'ID não fornecido'], 400);
        }
        break;
        
    case 'DELETE':
        if ($id) {
            // Deletar hino
            deleteHino($conn, $id);
        } else {
            jsonResponse(['error' => 'ID não fornecido'], 400);
        }
        break;
        
    default:
        jsonResponse(['error' => 'Método não permitido'], 405);
}

/**
 * GET /api/hinos
 * Lista hinos com filtros opcionais
 */
function listHinos($conn) {
    $categoria = $_GET['categoria'] ?? null;
    $compositor = $_GET['compositor'] ?? null;
    $ativo = $_GET['ativo'] ?? null;
    $page = max(1, intval($_GET['page'] ?? 1));
    $limit = min(100, max(1, intval($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;
    
    // Construir query
    $sql = "SELECT * FROM hinos WHERE 1=1";
    $params = [];
    
    if ($categoria) {
        $sql .= " AND categoria = ?";
        $params[] = $categoria;
    }
    
    if ($compositor) {
        $sql .= " AND compositor LIKE ?";
        $params[] = "%$compositor%";
    }
    
    if ($ativo !== null) {
        $sql .= " AND ativo = ?";
        $params[] = (int)$ativo;
    }
    
    // Count total
    $countSql = "SELECT COUNT(*) as total FROM hinos WHERE 1=1";
    if ($categoria) $countSql .= " AND categoria = ?";
    if ($compositor) $countSql .= " AND compositor LIKE ?";
    if ($ativo !== null) $countSql .= " AND ativo = ?";
    
    $countStmt = $conn->prepare($countSql);
    $countStmt->execute($params);
    $total = $countStmt->fetch()['total'];
    
    // Paginar
    $sql .= " ORDER BY numero ASC, created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $hinos = $stmt->fetchAll();
    
    jsonResponse([
        'hinos' => $hinos,
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'pages' => ceil($total / $limit)
    ]);
}

/**
 * GET /api/hinos/:id
 * Busca hino específico
 */
function getHino($conn, $id) {
    $stmt = $conn->prepare("SELECT * FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    $hino = $stmt->fetch();
    
    if (!$hino) {
        jsonResponse(['error' => 'Hino não encontrado'], 404);
    }
    
    jsonResponse($hino);
}

/**
 * POST /api/hinos
 * Cria novo hino
 */
function createHino($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validar dados obrigatórios
    if (empty($data['titulo']) || empty($data['audio_url'])) {
        jsonResponse(['error' => 'Título e áudio são obrigatórios'], 400);
    }
    
    $sql = "INSERT INTO hinos (numero, titulo, compositor, categoria, audio_url, cover_url, duracao, letra, tags, ativo) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        $data['numero'] ?? null,
        $data['titulo'],
        $data['compositor'] ?? null,
        $data['categoria'] ?? null,
        $data['audio_url'],
        $data['cover_url'] ?? null,
        $data['duracao'] ?? null,
        $data['letra'] ?? null,
        $data['tags'] ?? null,
        isset($data['ativo']) ? (int)$data['ativo'] : 1
    ]);
    
    $id = $conn->lastInsertId();
    
    // Buscar hino criado
    $stmt = $conn->prepare("SELECT * FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    $hino = $stmt->fetch();
    
    jsonResponse($hino, 201);
}

/**
 * PUT /api/hinos/:id
 * Atualiza hino existente
 */
function updateHino($conn, $id) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Verificar se hino existe
    $stmt = $conn->prepare("SELECT id FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Hino não encontrado'], 404);
    }
    
    // Construir UPDATE dinamicamente
    $fields = [];
    $params = [];
    
    $allowedFields = ['numero', 'titulo', 'compositor', 'categoria', 'audio_url', 'cover_url', 'duracao', 'letra', 'tags', 'ativo'];
    
    foreach ($allowedFields as $field) {
        if (isset($data[$field])) {
            $fields[] = "$field = ?";
            $params[] = $data[$field];
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'Nenhum campo para atualizar'], 400);
    }
    
    $sql = "UPDATE hinos SET " . implode(', ', $fields) . ", updated_at = NOW() WHERE id = ?";
    $params[] = $id;
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    
    // Buscar hino atualizado
    $stmt = $conn->prepare("SELECT * FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    $hino = $stmt->fetch();
    
    jsonResponse($hino);
}

/**
 * DELETE /api/hinos/:id
 * Deleta hino
 */
function deleteHino($conn, $id) {
    // Verificar se hino existe
    $stmt = $conn->prepare("SELECT id FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(['error' => 'Hino não encontrado'], 404);
    }
    
    // Deletar hino
    $stmt = $conn->prepare("DELETE FROM hinos WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'Hino deletado com sucesso']);
}
?>
