<?php
// api/send-email.php
// Envia email via SMTP usando PHPMailer. Lê credenciais de api/.env (não comitar com segredos).

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function load_env($path) {
  $vars = [];
  if (!file_exists($path)) return $vars;
  $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  foreach ($lines as $line) {
    if (strpos(trim($line), '#') === 0) continue;
    $parts = explode('=', $line, 2);
    if (count($parts) === 2) {
      $vars[trim($parts[0])] = trim(trim($parts[1]), "\"' ");
    }
  }
  return $vars;
}

try {
  $raw = file_get_contents('php://input');
  $payload = json_decode($raw, true);
  if (!$payload || empty($payload['to']) || empty($payload['subject']) || (empty($payload['html']) && empty($payload['text']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid payload']);
    exit;
  }

  $env = load_env(__DIR__ . '/.env');
  $SMTP_HOST = $env['SMTP_HOST'] ?? null;
  $SMTP_PORT = isset($env['SMTP_PORT']) ? intval($env['SMTP_PORT']) : 465;
  $SMTP_ENCRYPTION = strtolower($env['SMTP_ENCRYPTION'] ?? 'ssl'); // ssl|tls|none
  $SMTP_USER = $env['SMTP_USER'] ?? null;
  $SMTP_PASS = $env['SMTP_PASS'] ?? null;
  $FROM_EMAIL = $env['FROM_EMAIL'] ?? null;
  $FROM_NAME = $env['FROM_NAME'] ?? 'Mailer';

  if (!$SMTP_HOST || !$SMTP_USER || !$SMTP_PASS || !$FROM_EMAIL) {
    http_response_code(500);
    echo json_encode(['error' => 'Missing SMTP configuration in api/.env']);
    exit;
  }

  $mail = new PHPMailer(true);
  try {
    $mail->isSMTP();
    $mail->Host = $SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = $SMTP_USER;
    $mail->Password = $SMTP_PASS;
    if ($SMTP_ENCRYPTION === 'ssl') {
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // ssl
    } elseif ($SMTP_ENCRYPTION === 'tls') {
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // tls
    } else {
      $mail->SMTPSecure = false;
    }
    $mail->Port = $SMTP_PORT;

    $mail->setFrom($FROM_EMAIL, $FROM_NAME);
    $mail->addAddress($payload['to']);
    if (!empty($env['REPLY_TO_EMAIL'])) {
      $mail->addReplyTo($env['REPLY_TO_EMAIL']);
    }

    $mail->isHTML(!empty($payload['html']));
    $mail->Subject = $payload['subject'];
    $mail->Body = $payload['html'] ?? '';
    $mail->AltBody = $payload['text'] ?? '';

    $mail->send();

    echo json_encode(['success' => true]);
    exit;
  } catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $mail->ErrorInfo]);
    exit;
  }
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
  exit;
}
